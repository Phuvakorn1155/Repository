import 'work';

void main(List<String> args) {
var Laptop = Laptop ("01", 'Samsung Galaxy Book4 Ultra',32);
 Laptop.display(); 

var House = House();
 House.display();
var House1 = House("0001", 'Wayne Manor' ,3210000);
House.display();

var Car("Honda",'Sonic Grey Pearl', 166000);
  Car.setPrice(200000.0);
  Car.display();
  Car.setPrice(220000.0);
  Car.display();
}