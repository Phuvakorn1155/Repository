bool isEven(int number) {
  if (number % 2 == 0) {
    print('You are Active!'); // Number is even
    return true;
  } else {
    print('You are not Active!'); // Number is odd
    return false;
  }
}

double triangleArea(double base, double height) => 0.5 * base * height;

void rectangleArea([double width = 12, double length = 1]) {
  double area = width * length;
  print("The area of the rectangle is $area");
}

void main() {
  // Testing isEven function
  print(isEven(4));  // Output: You are Active!
  print(isEven(3));  // Output: You are not Active!

  // Testing triangleArea function
  print("The area of the triangle is ${triangleArea(10, 20)}");

  // Testing rectangleArea function
  rectangleArea();
  rectangleArea(10);
  rectangleArea(20, 40);
  rectangleArea(5, 10);
}