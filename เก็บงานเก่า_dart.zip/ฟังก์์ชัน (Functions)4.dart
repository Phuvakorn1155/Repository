import 'dart:math';

String generateRandomPassword(int length) {
  const characters = 'qazwsxedcrfvtgbyhnujmiklopQAZWSXEDCRFVTGBYHNUJMIKLOP0123456789!@#\$%^&*()_+[]{}|;:,.<>?';
  Random rand = Random();
  String password = '';

  for (int i = 0; i < length; i++) {
    int index = rand.nextInt(characters.length);
    password += characters[index];
  }

  return password;
}

void main() {
  // สร้างรหัสผ่านความยาว 12 ตัวอักษร
  String randomPassword = generateRandomPassword(12);
  print('รหัสผ่านแบบสุ่ม: $randomPassword');

  // สร้างรหัสผ่านความยาว 6 ตัวอักษร
  String anotherPassword = generateRandomPassword(6);
  print('รหัสผ่านแบบสุ่มอีกอันครั้ง: $anotherPassword');
}
