void printEvenNumbers(int start, int end) {
  print('เลขคู่ระหว่าง $start และ $end:');
  for (int i = start; i <= end; i++) {
    if (i % 2 == 0) {
      print(i);
    }
  }
}

void main() {
  // เรียกใช้ฟังก์ชันพิมพ์เลขคู่ระหว่าง 10 ถึง 30
  printEvenNumbers(10, 30);
}
