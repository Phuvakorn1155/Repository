int add(int num1, int num2) {
  return num1 + num2; // ส่งกลับผลรวมของ num1 และ num2
}

void main() {
  int number1 = 23;
  int number2 = 27;
  int sum = add(number1, number2);
  print('ผลรวมของ $number1 และ $number2 คือ $sum');

  int number3 = 95;
  int number4 = 97;
  int sum2 = add(number3, number4);
  print('ผลรวมของ $number3 และ $number4 คือ $sum2');
}
