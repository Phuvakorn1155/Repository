void main(){
Map<String, String> countryCapital = {
'USA': 'Washington, D.C.',
'India': 'New Delhi',
'China': 'Beijing'
};
print(countryCapital);
}