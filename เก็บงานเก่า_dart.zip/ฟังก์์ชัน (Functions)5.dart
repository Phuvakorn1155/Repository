import 'dart:math';

double calculateCircleArea(double radius) {
  const double pi = 3.14159265359; // หรือใช้ pi จาก 'dart:math'
  return pi * radius * radius; // ใช้สูตรพื้นที่วงกลม พาย * รัศมี * รัศมี
}

void main() {
  double radius1 = 5.0;
  double area1 = calculateCircleArea(radius1);
  print('พื้นที่ของวงกลมที่มีรัศมี $radius1 is $area1');

  double radius2 = 10.0;
  double area2 = calculateCircleArea(radius2);
  print('พื้นที่ของวงกลมที่มีรัศมี $radius2 is $area2');
}
