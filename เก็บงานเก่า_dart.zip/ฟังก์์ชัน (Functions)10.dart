bool isEven(int number) {
  return number % 2 == 0; // คืนค่า true ถ้าหาก number หารด้วย 2 ลงตัว มิฉะนั้นคืนค่า false
}

void main() {
  int number1 = 10;
  bool result1 = isEven(number1);
  print('$number1 เท่ากัน: $result1');

  int number2 = 7;
  bool result2 = isEven(number2);
  print('$number2 เท่ากัน: $result2');

  int number3 = 4;
  bool result3 = isEven(number3);
  print('$number3 เท่ากัน: $result3');

  int number4 = 13;
  bool result4 = isEven(number4);
  print('$number4 เท่ากัน: $result4');
}
