void greet(String name) {
  print('Hi!, $name');
}

void main() {
  // ตัวอย่างการเรียกใช้งานฟังก์ชัน greet
  greet('John'); // Hi!, John"
  greet('MAX'); // Hi!, MAX"
}
