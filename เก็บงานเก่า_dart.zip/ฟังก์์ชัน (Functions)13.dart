double triangleArea(double base, double height) => 0.5 * base * height;

void main() {
  // ทดสอบฟังก์ชัน triangleArea
  double base1 = 10;
  double height1 = 5;
  double area1 = triangleArea(base1, height1);
  print('พื้นที่ของสามเหลี่ยมที่มีฐาน $base1 และความสูง $height1 = $area1');

  double base2 = 6;
  double height2 = 4;
  double area2 = triangleArea(base2, height2);
  print('พื้นที่ของสามเหลี่ยมที่มีฐาน $base2 และความสูง $height2 = $area2');
}
