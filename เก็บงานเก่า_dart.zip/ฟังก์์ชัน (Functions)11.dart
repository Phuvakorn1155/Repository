void createUser(int age, {bool isActive = true}) {
  print('ผู้ใช้ตามอายุ: $age และกำลังใช้งานอยู่: $isActive');
}

void main() {
  // สร้างผู้ใช้โดยกำหนดทั้ง age และ isActive
  createUser(25, isActive: false);

  // สร้างผู้ใช้โดยกำหนดเฉพาะ age
  createUser(30);
}
