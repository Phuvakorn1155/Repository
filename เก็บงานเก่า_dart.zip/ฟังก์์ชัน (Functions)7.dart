int power(int base, int exponent) {
  int result = 1;
  for (int i = 0; i < exponent; i++) {
    result *= base; // คูณผลลัพธ์ด้วยฐาน (base) ในแต่ละรอบ
  }
  return result; // คืนค่าผลลัพธ์
}//5^3=125

void main() {
  int base1 = 5;
  int exponent1 = 3;
  int result1 = power(base1, exponent1);
  print('$base1^$exponent1 = $result1');
//2^5 = 32
  int base2 = 2;
  int exponent2 = 5;
  int result2 = power(base2, exponent2);
  print('$base2^$exponent2 = $result2');
}
