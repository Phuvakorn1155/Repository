import 'dart:math';

int pow(int a, int b) {
  int result = 1; //กำหนดค่าเริ่มต้นผลลัพธ์เป็น 1
  for (var i = 0; i < b; i++) { //ใช้ตัวแปร 'i' สำหรับลูป
    result *= a; //คูณผลลัพธ์ด้วย 'a' ในแต่ละรอบ
  }
  return result;
}

List<int> myScore(int number, int min, int max) {
  List<int> myScore = []; //  inteagerจำนวนเต็ม แบบ list
  var rand = Random();

  for (var i = 0; i < number; i++) {
    myScore.add(rand.nextInt(max - min + 1) + min); //random score
  }
  return myScore; // Return the list of scores
}


double calculateAverage(List<int> scores) {
  //if (scores.isEmpty) return 0.0; // เช็คว่ามีคะแนนไหม
  double sum = 0; // กำหนดค่าเริ่มต้นผลรวมเป็น 0
  for (int i = 0; i < scores.length; i ++ ) {
    sum += scores[i]; // รวมคะแนนทั้งหมด
  }
  return sum / scores.length; // คำนวณค่าเฉลี่ย
}

//Average มีoutput แบบ double
//Output:
//3^3 = 512
//2^5 = 32
//Random scores: [64, 85, 53, 76, 91] //คะแนนสุ่ม 5 คะแนนระหว่าง 10 ถึง 100
//Average score: 73.8 ตัวอย่างค่าเฉลี่ย; จะแตกต่างกันไปตามคะแนนสุ่ม

//function inteagerจำนวนเต็ม แบบ list
//Output:
//3^3 = 512
//2^5 = 32
//Random scores: [64, 85, 53, 76, 91] //คะแนนสุ่ม 5 คะแนนระหว่าง 10 ถึง 100
//Average score: 73.8 // ตัวอย่างค่าเฉลี่ย; จะแตกต่างกันไปตามคะแนนสุ่ม
//Generated integers: [5, 17, 12, 9, 3] // จำนวนเต็ม


void main(List<String> args) {
  print('3^3 = ${pow(8, 3)}'); 
  print('2^5 = ${pow(2, 5)}');
  //print('4^6 = ${pow(4, 6)}'); 
  //print('1^7 = ${pow(1, 7)}');

  //ตัวอย่างการใช้งานฟังก์ชั่น myScore
  List<int> myscores = myScore(5, 50, 100); //คะแนนสุ่ม 5 คะแนนระหว่าง 10 ถึง 100
  print('Random scores: $myscores');


  print('Generated integers: $myscores');
double average = calculateAverage(myscores);
  print('Average of generated integers: $average');


}