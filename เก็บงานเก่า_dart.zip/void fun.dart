void main(List<String> ages) {
print('main');
a();
s();
a();
}

void  a(){
print('fun a');
}

void  s(){
print('fun s');
}

