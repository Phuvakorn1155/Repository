void main() {
  // Initialize myMap as a Map
  var myMap = <String, double>{};
  print('Initial length of myMap: ${myMap.length}');

  // Adding key-value pairs to myMap
  myMap = {'A': 4.00, 'B+': 3.5, 'B': 3.0};
  print('Length of myMap: ${myMap.length}');

  // Adding a new entry
  myMap['C+'] = 2.5; 
  print(myMap.entries);
  print(myMap);

  // Another map to add
  Map<String, double> isMap = {'C': 2.00, 'D+': 1.5, 'D': 1.0};
  myMap.addAll(isMap); // Corrected method name to addAll

  print(myMap);

  // Remove 'D'
  myMap.remove('D');
  print(myMap);

  // Attempt to remove 'F' if it exists
  if (myMap.containsKey('F')) {
    myMap.remove('F');
  } else {
    print('myMap[F] = ${myMap['F']}');
  }

  print(myMap);

  // Iterate over keys
  for (var key in myMap.keys) {
    print('myMap[$key] = ${myMap[key]}');
  }

  // Using forEach to iterate over the map
  myMap.forEach((k, v) {
    print('myMap[$k] = $v');
  });
}
