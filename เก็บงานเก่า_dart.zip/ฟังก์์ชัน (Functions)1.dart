void printName(String name) {
  print('ชื่อของนักศึกษา: $name');
}

void main() {
  // เรียกใช้ฟังก์ชันและพิมพ์ชื่อของนักศึกษา
  printName('วันดี');
  printName('สมัย');
}