String reverseString(String input) {
  // สร้างลิสต์จากตัวอักษรของสตริง
  List<String> characters = input.split('');
  
  // กลับลำดับของลิสต์
  List<String> reversedCharacters = characters.reversed.toList();
  
  // รวมลิสต์ที่กลับลำดับแล้วให้เป็นสตริง
  String reversedString = reversedCharacters.join('');
  
  return reversedString;
}

void main() {
  // ทดสอบฟังก์ชัน reverseString
  String word1 = 'dog';
  String reversedWord1 = reverseString(word1);
  print('การย้อนกลับของ คำ "$word1" คือ "$reversedWord1"');
  
  String word2 = 'god';
  String reversedWord2 = reverseString(word2);
  print('การย้อนกลับของ คำ "$word2" คือ "$reversedWord2"');
}
//การย้อนกลับของ คำ "Dog" คือ "goD"
//การย้อนกลับของ คำ "God" คือ "doG"