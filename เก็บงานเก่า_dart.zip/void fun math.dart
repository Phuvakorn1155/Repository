import 'dart:math';

int add(int n1, int n2) {
  int x = n1 + n2;
  return x;
}

int randInt(int min, int max) {
  var rand = Random(); // Corrected initialization of Random
  return rand.nextInt(max - min + 1) + min; // Fixed random number generation logic
}

void main() {
  int n = add(10, 20);
  var m = add(40, 50);
  print('Sum of 10 and 20: $n');
  print('Sum of 40 and 50: $m');
  print('Random number is ${randInt(1, 10)}');
}
