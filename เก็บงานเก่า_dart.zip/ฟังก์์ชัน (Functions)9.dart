int maxNumber(int num1, int num2, int num3) {
  int max = num1; // สมมติให้ num1 เป็นค่ามากที่สุดในตอนแรก

  if (num2 > max) {
    max = num2; // ถ้า num2 มากกว่า max ให้ max เป็น num2
  }

  if (num3 > max) {
    max = num3; // ถ้า num3 มากกว่า max ให้ max เป็น num3
  }

  return max; // คืนค่าที่มากที่สุด
}

void main() {
  int number1 = 10;
  int number2 = 20;
  int number3 = 15;
  int max1 = maxNumber(number1, number2, number3);
  print('จำนวนสูงสุดระหว่าง $number1, $number2, และ $number3 คือ $max1');

  int number4 = 5;
  int number5 = 7;
  int number6 = 3;
  int max2 = maxNumber(number4, number5, number6);
  print('จำนวนสูงสุดระหว่าง $number4, $number5, และ $number6 คือ $max2');
}
