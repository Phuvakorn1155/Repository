class Cat{
  
  String _species;
  Cat (this._species);

   String get species => this._species;
   String make_sound() => "Meow";
   
}