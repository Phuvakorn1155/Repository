class Laptop {
  int? id;
  String? name;
  int? ram;
  Laptop({this.id, this.name, this.ram});

   void display() {
    print('ID: $id, Name: $name, RAM: ${ram ?? 0}GB');
  }
}

class House {
  int? id;
  String? name;
  double? price;

  House(this.id, this.name, this.price);

  
  void display() {
    print('ID: $id, Name: $name, Price: \$${price?.toStringAsFixed(2) ?? '0.00'}');
  }
}

class Car {
  String? brand;
  String? color;
  double price;

  Car(this.brand, this.color, [this.price = 0.0]);

   void display() {
    print('Brand: $brand, Color: $color, Price: \$${price.toStringAsFixed(2)}');
  }

 
  void setPrice(double newPrice) {
    price = newPrice;
  }
}

void main() {
 
  Laptop laptop1 = Laptop(id: 1, name: 'HUAWEI MateBook X Pro', ram: 32);
  Laptop laptop2 = Laptop(id: 2, name: 'HUAWEI MateBook 14s', ram: 8);
  Laptop laptop3 = Laptop(id: 3, name: 'HUAWEI MateBook D 15', ram: 16);

  laptop1.display();
  laptop2.display();
  laptop3.display();

  House house1 = House(1, 'Wayne Manor', 3210000.00);
  House house2 = House(2, 'Nottingham', 6000000.00);
  House house3 = House(3, 'Mentmore Towers', 4708533.00);

  house1.display();
  house2.display();
  house3.display();

  Car car1 = Car('Mitsubishi', 'Red', 1900.00);
  Car car2 = Car('Honda', 'Blue'); //0.00
  Car car3 = Car('Nissan', 'Black', 1800.00);

  print('Before changing the price:');
  car1.display();
  car2.display();
  car3.display();

  // เปลี่ยนแปลงราคารถ2
  car2.setPrice(2200.00);

  print('After changing the price:');
  car1.display();
  car2.display();
  car3.display();
}