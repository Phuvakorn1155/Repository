class Mammal{
  
  String _species;
   Mammal (this._species);

   String get species => this._species;
   String make_sound() => "Grrrrr";
   
}