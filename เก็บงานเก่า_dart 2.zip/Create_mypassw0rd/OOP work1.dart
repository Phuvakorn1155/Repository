class Laptop {
  int? id;
  String? name;
  int? ram;

  // Constructor with named optional parameters
  Laptop({this.id, this.name, this.ram});

  // Method to display laptop details
  void display() {
    print('ID: $id, Name: $name, RAM: ${ram ?? 0}GB');
  }
}

class House {
  int? id;
  String? name;
  double? price; // Use 'double' instead of 'Double'

  // Constructor
  House(this.id, this.name, this.price);

  // Method to display house details
  void display() {
    print('ID: $id, Name: $name, Price: \$${price?.toStringAsFixed(2) ?? 'N/A'}');
  }
}

class Car {
  String? brand;
  String? color;
  double? price;

  // Constructor with default price
  Car(this.brand, this.color, [this.price = 0.0]);

  // Method to display car details
  void display() {
    print('Brand: $brand, Color: $color, Price: \$$price');
  }
}

void main() {
  // Create and display instances of Laptop
  Laptop laptop1 = Laptop(id: 1, name: 'HUAWEI MateBook X Pro', ram: 32);
  Laptop laptop2 = Laptop(id: 2, name: 'HUAWEI MateBook 14s', ram: 8);
  Laptop laptop3 = Laptop(id: 3, name: 'HUAWEI MateBook D 15', ram: 16);

  laptop1.display();
  laptop2.display();
  laptop3.display();

  // Create and display instances of House
  House house1 = House(01, 'Wayne Manor', 3210000.00);
  House house2 = House(02, 'Nottingham', 6000000.00);
  House house3 = House(03, 'Mentmore Towers', 4708533.00);

  house1.display();
  house2.display();
  house3.display();

  Car car1 = Car('Mitsubishi', 'Red', 1900.00);
  Car car2 = Car('Honda', 'Blue');
  Car car3 = Car('Nissan', 'Black', 1800.00);

  car1.display();
  car2.display();
  car3.display();
}