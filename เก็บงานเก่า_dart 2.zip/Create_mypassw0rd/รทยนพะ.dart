import 'dart08.09.dart';

void main(List<String> args) {
  
Animal dog = new Animal();
dog.name = 'Dang';
dog.nleg = 4;
dog.span = 20;
dog.display();
 
 Animal cat = Animal ();
 cat.name = 'meo';
 cat.nleg = 4;
 cat.span = 2;
 cat.display();
 

var rec1 = Rectang();
var rec2 = Rectang();
rec1.length=8.9;

rec2.length=7.8;
rec1.width=4.6;
rec2.width=8.9;
rec1.show();
rec2.show();
 }
