class Animal {
  int? nleg;
  String? name;
  int? span;

  // Method to display animal details
  void display() {
    print('Name: $name');
    print('Legs: $nleg');
    print('Span: $span');
  }
}

class Book {
  String? type;
  String? name;
  double? price;

  // Method to display book details
  void display() {
    print('Name: $name');
    print('Type: $type');
    print('Price:$price');
  }
}

class Rectang {
  double? width;
  double? length;

  // Method to calculate area
  double? area() {
    if (width != null && length != null) {
      return width! * length!;
    }
    return null; // Return null if width or length is null
  }

  // Method to display rectangle details
  void show() {
    double? areaValue = area();
    print('Area = ${areaValue?.toStringAsFixed(2)} width = $width length = $length');
  }
}

void main() {
  // Create and display animal
  Animal animal = Animal()
    ..name = 'Elephant'
    ..nleg = 4
    ..span = 70;
  animal.display();

  // Create and display book
  Book book = Book()
    ..name = 'Dart Programming'
    ..type = 'Educational'
    ..price = 29.99;
  book.display();

  // Create and display rectangle
  Rectang rect = Rectang()
    ..width = 14.5
    ..length = 15.5;
  rect.show();
}