class Dog{
  
  String _species;
 Dog (this._species);

   String get species => this._species;
   String make_sound() => "Woof";
   
}